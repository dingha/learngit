
Page({

  /**
   * 页面的初始数据
   */
  data: {
    toastshows:false,
    paramAtoB: "我是A向B传值", 
    img:"../../../images/ring@3x.png",
    emptyshow:false,
    active: 0,
    orderdata:[
          {
            title:"标题",
            titlechecked: false,
            titlevalue:"卖家已经发货",
            goods:[
              {name:"几何茶几",spec1:"核桃木色",spec2:"12*55*12",goodsimg:"../../../images/pingjiapic@3x.png",price:32,num:3}
            ],
            comnum:2,comprice:3
          },
          {
            titlechecked: false,
            titlevalue:"卖家已经发货",
            goods:[
              {name:"几何茶几",spec1:"核桃木色",spec2:"12*55*12",goodsimg:"../../../images/pingjiapic@3x.png",price:32,num:3},
              {name:"几何茶几",spec1:"核桃木色",spec2:"12*55*12",goodsimg:"../../../images/pingjiapic@3x.png",price:32,num:3}
            ],
            comnum:2,comprice:3
          }
      ],
      paymentdata:[
        {
          title:"j家居几何",
          titlechecked: false,
          titlevalue:"等待买家付款",
          goods:[
            {name:"几何茶几",spec1:"核桃木色",spec2:"12*55*12",goodsimg:"../../../images/pingjiapic@3x.png",price:32,num:3}
          ],
          comnum:2,comprice:3
        },
        {
          title:"j家居几何",
          titlechecked: false,
          titlevalue:"等待买家付款",
          goods:[
            {name:"几何茶几",spec1:"核桃木色",spec2:"12*55*12",goodsimg:"../../../images/pingjiapic@3x.png",price:32,num:3},
            {name:"几何茶几",spec1:"核桃木色",spec2:"12*55*12",goodsimg:"../../../images/pingjiapic@3x.png",price:32,num:3}
          ],
          comnum:2,comprice:3
        }
    ]
  },

  titleChange(event) {
    const index=event.currentTarget.dataset.index
    console.log(demo01)
    this.setData({
      [demo01]: event.detail,
    });
  },

  // 待付款取消订单
  calloff(event){
    this.setData({
      toastshows: event.detail,
    });
  },

  ontabChange(event) {
    wx.showToast({
      title: `切换到标签 ${event.detail.name}`,
      icon: 'none',
    });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})