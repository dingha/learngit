

Page({

  /**
   * 页面的初始数据
   */
  data: {
    setchecked: true,
    Aboutmy:false,
    set:true,
    totallist:[
      {name:"功能介绍"},
      {name:"公司介绍"},
      {name:"新版本检查"}
    ],
    setlist:[
      {name:"关于我们",content:""},
      {name:"意见反馈",content:""},
      {name:"在线客服",content:""},
      {name:"清除缓存",content:"0.00kb"}
    ]
  },
// 通知推送开关
  setonChange({ detail }) {
    // 需要手动对 checked 状态进行更新
    this.setData({ setchecked: detail });
  },
  // 底部总目录 total 点击事件
  total(e){
    const name=e.currentTarget.dataset.name;
      switch(name){
        case '功能介绍':
          wx.showToast({
            title: name
            });

        return ;
      case '公司介绍':
        wx.showToast({
          title: name
          });
        return ;
      case '新版本检查':
        wx.showToast({
          title: name
          });
        return 'run';
  }
  },
  // 底部总目录 set 点击事件
  set(e){
    const name=e.currentTarget.dataset.name;
      switch(name){
        case '关于我们':
          wx.showToast({
            title: name
            });

        return ;
      case '意见反馈':
        wx.showToast({
          title: name
          });
        return ;
      case '在线客服':
        wx.showToast({
          title: name
          });
        return 'run';
      case '清除缓存':
        

        // Toast('我是提示文案，建议不超过十五字~');
        // <van-toast id="van-toast" />

        wx.showToast({
          title: "缓存已成功清理",
          icon:"none",
          });
        return 'run';
  }
  },






  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})