// pages/my/Setup/setup/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    leave: '',
    tel:"",
    totallist:[
      {name:"功能介绍"},
      {name:"公司介绍"},
      {name:"新版本检查"}
    ]
  },
  leaveChange(event) {
    // event.detail 为当前输入的值
    console.log(event.detail);
  },
  // 底部总目录 total 点击事件
  total(e){
    const name=e.currentTarget.dataset.name;
    
      switch(name){
        case '功能介绍':
          wx.showToast({
            title: name
            });

        return ;
      case '公司介绍':
        wx.showToast({
          title: name
          });
        return ;
      case '新版本检查':
        wx.showToast({
          title: name
          });
        return 'run';
  }
  },






  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})