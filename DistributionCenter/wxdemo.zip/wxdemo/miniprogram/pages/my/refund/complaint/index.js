// pages/my/refund/complaint/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    successful:false,
    inhandshow:false,
    rejectedshow:true,
    inhanddata:{
      goodsimg:"../../../../images/pingjiapic@3x.png",name:"木质家具",price:"￥20",
      photo:[{img:"../../../../images/cangpin@3x.png"},{img:"../../../../images/zupic@3x.png"}],
      reason:"投诉理由：发货时间与拍下不符合，商家都不理我",
      phone:"13588545454",
      date:"2017-07-25",
      okimg:"../../../../images/success@3x.png",
      inhandimg:"../../../../images/loading@3x.png",
      rejectedimg:"../../../../images/bohui@3x.png",
      rejectedreason:"经核查，。客户是骗子，不允许骗子胡闹"
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})