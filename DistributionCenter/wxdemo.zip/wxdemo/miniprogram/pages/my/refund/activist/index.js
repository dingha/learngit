// pages/my/refund/activist/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    tabshow:true,
    detailsshow:false,
    active: 1,
    activistlist:[
      {img:"../../../../images/xiaojiejie@3x.png",name:"家居",chat:"请你确认一下收货地址",date:"2017-07-22"},
      {img:"../../../../images/xiaojiejie@3x.png",name:"家t居",chat:"请你确认一下收货地址",date:"2017-07-22"},
      {img:"../../../../images/xiaojiejie@3x.png",name:"家2居",chat:"请你确认一下收货地址",date:"2017-07-22"},
    ],
    refundlist:[
      {img:"../../../../images/pingjiapic@3x.png",name:"家居",spec:"300*520*522;黑胡桃木",color:"胡桃木色",price:29,},
      {img:"../../../../images/pingjiapic@3x.png",name:"家居",spec:"300*520*522;黑胡桃木",color:"胡桃木色",price:29,},
      {img:"../../../../images/pingjiapic@3x.png",name:"家居",spec:"300*520*522;黑胡桃木",color:"胡桃木色",price:29,},
    ],
    complainlist:[
      {img:"../../../../images/pingjiapic@3x.png",name:"家居",spec:"投诉理由：产品太丑",color:"胡桃木色"},
      {img:"../../../../images/pingjiapic@3x.png",name:"家居",spec:"投诉理由：产品太丑桃木",color:"胡桃木色"},
      {img:"../../../../images/pingjiapic@3x.png",name:"家居",spec:"投诉理由：产品太丑胡桃木",color:"胡桃木色"},
    ],
    
  },

  tabChange(event) {
    wx.showToast({
      title: `切换到标签 ${event.detail.name}`,
      icon: 'none',
    });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
      
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})