// pages/my/index.js
Page({

  header(e){
    const id=e.currentTarget.dataset.id;
    const name=e.currentTarget.dataset.name;
    let name01='toplist.bottomdata['+id+'].name';
    switch(name){
          case '签到':
            this.setData({
            [name01]:"已签到"
             })
            return 
        case '收藏':
          return '分享';
        case '分享':
          return 'run';
        case '足迹':
          return 'run';
    }
  },
  myorderbtm(e){
    const name=e.currentTarget.dataset.name;
    switch(name){
          case '待付款':
            wx.showToast({
              title: name
              });
          return 
        case '待发货':
          wx.showToast({
            title: name
            });
          return ;
        case '配送中':
          wx.showToast({
            title: name
            });
          return 'run';
        case '待评价':
          wx.showToast({
            title: name
            });
          return 'run';
    }
  },
    bottomlist1(e){
      const name=e.currentTarget.dataset.name;
    switch(name){
          case '会员等级':
            wx.showToast({
              title: name
              });
          return 
        case '我的积分':
          wx.showToast({
            title: name
            });
          return ;
        case '我的卡券':
          wx.showToast({
            title: name
            });
          return 'run';
    }
    },
    bottomlist2(e){
      const name=e.currentTarget.dataset.name;
    switch(name){
          case '我的评价':
            wx.showToast({
              title: name
              });
          return 
        case '退款维权':
          wx.showToast({
            title: name
            });
          return ;
    }
    },
    bottomlist3(e){
      const name=e.currentTarget.dataset.name;
    switch(name){
          case '我的预约体验':
            wx.showToast({
              title: name
              });
          return 
        case '我的预约设计':
          wx.showToast({
            title: name
            });
          return ;
    }
    },
    onClickLeft() {
      wx.showToast({ title: '点击返回', icon: 'none' });
    },
    onClickRight() {
      wx.showToast({ title: '点击按钮', icon: 'none' });
    },

  /**
   * 页面的初始数据
   */
  data:{
      toplist:{
        NavbarLeftimg:"../../images/set@3x.png",
        NavbarRightimg:"../../images/ring@3x.png",
        myname:"一不小心闪到腰",
        bottomdata:[
          {name:"签到",img:"../../images/qian-@3x.png"},
          {name:"收藏",img:"../../images/shou@3x.png"},
          {name:"分享",img:"../../images/sharee@3x.png"},
          {name:"足迹",img:"../../images/foot@3x.png"}
        ]
      },
      myorder:{
        orderimg:[
          {name:"待付款",img:"../../images/fu@3x.png"},
          {name:"待发货",img:"../../images/fa@3x.png"},
          {name:"配送中",img:"../../images/song@3x.png"},
          {name:"待评价",img:"../../images/ping@3x.png"}

        ]
      },
      bottomlist1:[
        {name:"会员等级",img:"../../images/guan@3x.png"},
        {name:"我的积分",img:"../../images/fen@3x.png"},
        {name:"我的卡券",img:"../../images/ka@3x.png"}
      ],
      bottomlist2:[
        {name:"我的评价",img:"../../images/pingp@3x.png"},
        {name:"退款维权",img:"../../images/tui@3x.png"}
      ],
      bottomlist3:[
        {name:"我的预约体验",img:"../../images/ti@3x.png"},
        {name:"我的预约设计",img:"../../images/she@3x.png"},
      ],
      datalist:[
      ]

    
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
// 获取用户信息
  wx.getSetting({ 
  success: res => {
    if (res.authSetting['scope.userInfo']) {
      // 已经授权，可以直接调用 getUserInfo 获取头像昵称，不会弹框
      wx.getUserInfo({
        success: res => {
          this.setData({
            avatarUrl: res.userInfo.avatarUrl
          })
        }
      })
    }
  }
})
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})