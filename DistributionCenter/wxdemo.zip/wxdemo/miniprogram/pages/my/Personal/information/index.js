// pages/my/Personal/information/index.js
Page({
  onClickHide() {
    this.setData({ onshow: false });
  },
  dateClickHide() {
    this.setData({ dateshow: false });
  },
  sexClickHide() {
    this.setData({ sexshow: false });
  },
  
  bottomlist1(e){
    const name=e.currentTarget.dataset.name;
    
      switch(name){
        case '昵称':
          this.setData({
            onshow:true
             })

        return ;
      case '性别':
        this.setData({
          sexshow:true
           })
        return ;
      case '年龄':
        this.setData({
          dateshow:true
           })
        return 'run';
  }
  },

  /**
   * 页面的初始数据
   */
  data: {
    radio: '1',
    sexshow:false,
    onshow:false,
    dateshow:false,
    fileList: [],
    datalist:{
      NavbarLeftimg:"../../../../images/set@3x.png",
      NavbarRightimg:"../../../../images/ring@3x.png",
      bottomdata1:[
        {name:"昵称",content:"一不小心闪到腰",show:true,onshow:true},
        {name:"性别",content:"男",show:true,onshow:false},
        {name:"年龄",content:"",show:true,onshow:false}
      ],
      bottomdata2:[
        {name:"地址",content:"北京市大港湾",show:true,onshow:false},
        {name:"实名认证",content:"个人实名认证",show:true,onshow:false}
      ]
    },
    currentDate: new Date().getTime(),
    minDate: new Date().getTime(),
    formatter(type, value) {
      if (type === 'year') {
        return `${value}年`;
      } else if (type === 'month') {
        return `${value}月`;
      }
      return value;
    },
  },
  // 年月日
  onInput(event) {
    this.setData({
      currentDate: event.detail,
    });
  },
  // 性别
  onChange(event) {
    this.setData({
      radio: event.detail,
    });
  },
  afterRead(event) {
    console(1)
    const { file } = event.detail;
    // 当设置 mutiple 为 true 时, file 为数组格式，否则为对象格式
    wx.uploadFile({
      url: 'https://example.weixin.qq.com/upload', // 仅为示例，非真实的接口地址
      filePath: file.path,
      name: 'file',
      formData: { user: 'test' },
      success(res) {
        // 上传完成需要更新 fileList
        const { fileList = [] } = this.data;
        fileList.push({ ...file, url: res.data });
        this.setData({ fileList });
      },
    });
  },






  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    const bottomdata1=this.data.datalist.bottomdata1
    const bottomdata2=this.data.datalist.bottomdata2
    bottomdata1.forEach((item,index)=>{
    let name01='datalist.bottomdata1['+index+'].show';
      if (!item.content.length == 0) {
        this.setData({
          [name01]:false
           })
    }})
    bottomdata2.forEach((item,index)=>{
    let name01='datalist.bottomdata2['+index+'].show';
      if (!item.content.length == 0) {
        this.setData({
          [name01]:false
           })
    }})
    // 获取用户信息
  wx.getSetting({ 
    success: res => {
      if (res.authSetting['scope.userInfo']) {
        // 已经授权，可以直接调用 getUserInfo 获取头像昵称，不会弹框
        wx.getUserInfo({
          success: res => {
            this.setData({
              avatarUrl: res.userInfo.avatarUrl
            })
          }
        })
      }
    }
  })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})